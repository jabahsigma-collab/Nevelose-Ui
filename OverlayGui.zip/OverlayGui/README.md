# Overlay GUI (визуальный макет)
1. Залей папку в GitHub-репозиторий.
2. Actions -> Build APK -> скачай app-debug из Artifacts.
3. Открой приложение, нажми INJECT, выдай разрешение "поверх других окон", нажми INJECT снова.
