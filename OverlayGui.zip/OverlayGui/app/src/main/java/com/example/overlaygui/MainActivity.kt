package com.example.overlaygui

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var btn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#0B1224"), Color.parseColor("#05070D"))
            )
        }
        val title = TextView(this).apply {
            text = "NIGHTFALL"
            setTextColor(Color.WHITE)
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.25f
            gravity = Gravity.CENTER
        }
        val sub = TextView(this).apply {
            text = "visual preview"
            setTextColor(Color.parseColor("#6E7C99"))
            textSize = 13f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Ready"
            setTextColor(Color.parseColor("#6E7C99"))
            textSize = 14f
            gravity = Gravity.CENTER
        }
        btn = Button(this).apply {
            text = "INJECT"
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.15f
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.parseColor("#3B82FF"), Color.parseColor("#7C5CFF"))
            ).apply { cornerRadius = 14 * d }
            setOnClickListener { inject() }
        }
        root.addView(title, LinearLayout.LayoutParams(-2, -2))
        root.addView(sub, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = (40 * d).toInt() })
        root.addView(btn, LinearLayout.LayoutParams((220 * d).toInt(), (54 * d).toInt()))
        root.addView(status, LinearLayout.LayoutParams(-2, -2).apply { topMargin = (18 * d).toInt() })
        setContentView(root)
    }

    private fun inject() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Разреши отображение поверх других окон", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        btn.isEnabled = false
        val h = Handler(Looper.getMainLooper())
        status.text = "Injecting."
        h.postDelayed({ status.text = "Injecting.." }, 400)
        h.postDelayed({ status.text = "Injecting..." }, 800)
        h.postDelayed({
            status.text = "Injected"
            startService(Intent(this, OverlayService::class.java))
            btn.isEnabled = true
            moveTaskToBack(true)
        }, 1300)
    }
}
