package com.example.overlaygui

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var btn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#05070D"))
        }
        status = TextView(this).apply {
            text = "Ready"
            setTextColor(Color.parseColor("#7C8AA5"))
            textSize = 14f
            gravity = Gravity.CENTER
        }
        btn = Button(this).apply {
            text = "INJECT"
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                cornerRadius = 12 * d
                setColor(Color.parseColor("#2D7DFF"))
            }
            setOnClickListener { inject() }
        }
        root.addView(btn, LinearLayout.LayoutParams((200 * d).toInt(), (52 * d).toInt()))
        root.addView(status, LinearLayout.LayoutParams(-2, -2).apply { topMargin = (16 * d).toInt() })
        setContentView(root)
    }

    private fun inject() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Разреши отображение поверх других окон", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        btn.isEnabled = false
        val h = Handler(Looper.getMainLooper())
        status.text = "Injecting."
        h.postDelayed({ status.text = "Injecting.." }, 400)
        h.postDelayed({ status.text = "Injecting..." }, 800)
        h.postDelayed({
            status.text = "Injected"
            startService(Intent(this, OverlayService::class.java))
            btn.isEnabled = true
            moveTaskToBack(true)
        }, 1300)
    }
}
