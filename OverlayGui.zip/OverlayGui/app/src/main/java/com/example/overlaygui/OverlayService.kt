package com.example.overlaygui

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

private val C_BG = Color.parseColor("#F2080C14")
private val C_PANEL = Color.parseColor("#0C121C")
private val C_CARD = Color.parseColor("#111A28")
private val C_CARD2 = Color.parseColor("#182338")
private val C_STROKE = Color.parseColor("#1E2B45")
private val C_ACCENT = Color.parseColor("#3B82FF")
private val C_ACCENT2 = Color.parseColor("#7C5CFF")
private val C_TEXT = Color.parseColor("#E3EAF6")
private val C_MUTED = Color.parseColor("#6E7C99")
private val C_OFF = Color.parseColor("#252E40")
private val C_GREEN = Color.parseColor("#34D399")
private val C_RED = Color.parseColor("#FF5470")

private const val MONEY_MAX = 999_999_999_999L

sealed class Item {
    data class Header(val text: String) : Item()
    data class Toggle(val label: String, val def: Boolean = false) : Item()
    data class Slider(val label: String, val min: Int, val max: Int, val def: Int, val suffix: String = "") : Item()
    data class Action(val label: String) : Item()
    object Money : Item()
}

class ToggleView(ctx: Context, initial: Boolean, private val onChange: (Boolean) -> Unit) : View(ctx) {
    var on = initial
        private set
    private var progress = if (initial) 1f else 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ev = ArgbEvaluator()
    private var anim: ValueAnimator? = null

    fun toggle() {
        on = !on
        onChange(on)
        anim?.cancel()
        anim = ValueAnimator.ofFloat(progress, if (on) 1f else 0f).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.color = ev.evaluate(progress, C_OFF, C_ACCENT) as Int
        c.drawRoundRect(0f, 0f, w, h, h / 2, h / 2, p)
        if (progress > 0f) {
            p.color = Color.argb((50 * progress).toInt(), 59, 130, 255)
            c.drawRoundRect(-2f, -2f, w + 2f, h + 2f, h / 2 + 2f, h / 2 + 2f, p)
            p.color = ev.evaluate(progress, C_OFF, C_ACCENT) as Int
            c.drawRoundRect(0f, 0f, w, h, h / 2, h / 2, p)
        }
        p.color = Color.WHITE
        val pad = h * 0.18f
        val r = h / 2 - pad
        val cx = h / 2 + progress * (w - h)
        c.drawCircle(cx, h / 2, r, p)
    }
}

class SliderView(
    ctx: Context, private val min: Int, private val max: Int, initial: Int,
    private val onChange: (Int) -> Unit
) : View(ctx) {
    var value = initial.coerceIn(min, max)
        private set
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val th = h * 0.22f
        val cy = h / 2
        val r = h * 0.38f
        val frac = (value - min).toFloat() / (max - min).toFloat()
        val x = r + frac * (w - 2 * r)
        p.color = C_OFF
        c.drawRoundRect(r, cy - th / 2, w - r, cy + th / 2, th / 2, th / 2, p)
        p.color = C_ACCENT
        c.drawRoundRect(r, cy - th / 2, x, cy + th / 2, th / 2, th / 2, p)
        p.color = Color.argb(60, 59, 130, 255)
        c.drawCircle(x, cy, r + 3f, p)
        p.color = Color.WHITE
        c.drawCircle(x, cy, r - 1f, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN) parent.requestDisallowInterceptTouchEvent(true)
        val r = height * 0.38f
        val frac = ((e.x - r) / (width - 2 * r)).coerceIn(0f, 1f)
        val nv = (min + frac * (max - min)).roundToInt()
        if (nv != value) {
            value = nv
            onChange(nv)
            invalidate()
        }
        return true
    }
}

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var gui: LinearLayout
    private lateinit var guiParams: WindowManager.LayoutParams
    private lateinit var openBtn: TextView
    private lateinit var openParams: WindowManager.LayoutParams
    private var openShown = false
    private var reselect: (() -> Unit)? = null

    private val ctx: Context get() = this
    private val prefs by lazy { getSharedPreferences("gui", MODE_PRIVATE) }
    private val density get() = resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()

    private val currencies = listOf("$", "€", "₽", "₼", "£", "¥")

    private val tabs: LinkedHashMap<String, List<Item>> = linkedMapOf(
        "Aimbot" to listOf(
            Item.Header("AIMBOT"),
            Item.Toggle("Enabled"), Item.Toggle("Auto fire"), Item.Toggle("Silent aim"),
            Item.Slider("FOV", 1, 180, 90, "°"),
            Item.Slider("Smooth", 0, 100, 35, "%"),
            Item.Header("ACCURACY"),
            Item.Toggle("Auto scope"), Item.Toggle("Auto stop"),
            Item.Slider("Hitchance", 0, 100, 70, "%")
        ),
        "Visuals" to listOf(
            Item.Header("ESP"),
            Item.Toggle("Box"), Item.Toggle("Name"), Item.Toggle("Health bar"), Item.Toggle("Skeleton"),
            Item.Header("EFFECTS"),
            Item.Toggle("Glow"), Item.Toggle("Chams"),
            Item.Slider("Opacity", 0, 100, 80, "%"),
            Item.Toggle("Radar")
        ),
        "Player" to listOf(
            Item.Header("ECONOMY"),
            Item.Money,
            Item.Header("MOVEMENT"),
            Item.Toggle("Bunny hop"), Item.Toggle("Auto strafe"),
            Item.Slider("Speed", 50, 200, 100, "%")
        ),
        "Misc" to listOf(
            Item.Header("INTERFACE"),
            Item.Toggle("Watermark"), Item.Toggle("Spectator list"), Item.Toggle("Keybind list"),
            Item.Header("SOUND"),
            Item.Toggle("Hit sound"),
            Item.Slider("Volume", 0, 100, 50, "%")
        ),
        "Config" to listOf(
            Item.Header("CONFIG"),
            Item.Toggle("Auto save", true), Item.Toggle("Show tooltips", true),
            Item.Action("Reset all settings")
        )
    )

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildGui()
        buildOpenButton()
    }

    // ---------- helpers ----------
    private fun rounded(color: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = r.toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun lp(x: Int, y: Int, w: Int) = WindowManager.LayoutParams(
        w, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(ctx).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun headerBtn(text: String, tint: Int, click: () -> Unit) = TextView(ctx).apply {
        this.text = text
        setTextColor(tint)
        textSize = 15f
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        background = rounded(C_CARD2, dp(9), C_STROKE)
        setOnClickListener { click() }
    }

    private fun chip(text: String, accent: Boolean, click: () -> Unit) = TextView(ctx).apply {
        this.text = text
        textSize = 11f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setTextColor(if (accent) Color.WHITE else C_TEXT)
        background = if (accent) GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(C_ACCENT, C_ACCENT2)
        ).apply { cornerRadius = dp(8).toFloat() } else rounded(C_CARD2, dp(8), C_STROKE)
        setOnClickListener { click() }
    }

    private fun fmt(v: Long): String = String.format(Locale.US, "%,d", v).replace(',', ' ')

    private fun setFocusable(f: Boolean) {
        guiParams.flags = if (f) WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        guiParams.softInputMode = if (f)
            WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN or WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
        else 0
        wm.updateViewLayout(gui, guiParams)
    }

    // ---------- main GUI ----------
    private fun buildGui() {
        guiParams = lp(prefs.getInt("x", dp(30)), prefs.getInt("y", dp(60)), dp(430))
        gui = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#F20B1220"), Color.parseColor("#F2060910"))
            ).apply { cornerRadius = dp(18).toFloat(); setStroke(dp(1), C_STROKE) }
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }

        // header
        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val dot = View(ctx).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR, intArrayOf(C_ACCENT, C_ACCENT2)
            ).apply { shape = GradientDrawable.OVAL }
        }
        header.addView(dot, LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(8) })
        val titleCol = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        titleCol.addView(label("NIGHTFALL", 15f, Color.WHITE, true).apply { letterSpacing = 0.18f })
        titleCol.addView(label("visual preview  •  v1.0", 10f, C_MUTED))
        header.addView(titleCol, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(headerBtn("–", C_TEXT) { hideGui() },
            LinearLayout.LayoutParams(dp(30), dp(30)).apply { rightMargin = dp(6) })
        header.addView(headerBtn("✕", C_RED) { stopSelf() }, LinearLayout.LayoutParams(dp(30), dp(30)))
        gui.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        attachDrag(header, guiParams, gui, null) {
            prefs.edit().putInt("x", guiParams.x).putInt("y", guiParams.y).apply()
        }

        // divider
        val line = View(ctx).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.TRANSPARENT, C_ACCENT, C_ACCENT2, Color.TRANSPARENT)
            )
        }
        gui.addView(line, LinearLayout.LayoutParams(-1, dp(1)).apply { bottomMargin = dp(8) })

        // body
        val body = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val side = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(C_PANEL, dp(12), C_STROKE)
            setPadding(dp(5), dp(6), dp(5), dp(6))
        }
        val holder = ScrollView(ctx).apply {
            background = rounded(C_PANEL, dp(12), C_STROKE)
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val tabViews = mutableListOf<TextView>()
        var current = prefs.getString("tab", tabs.keys.first()) ?: tabs.keys.first()
        if (!tabs.containsKey(current)) current = tabs.keys.first()

        fun select(name: String) {
            current = name
            prefs.edit().putString("tab", name).apply()
            tabViews.forEach { t ->
                val sel = t.tag == name
                t.setTextColor(if (sel) Color.WHITE else C_MUTED)
                t.typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                t.background = if (sel) GradientDrawable(
                    GradientDrawable.Orientation.LEFT_RIGHT,
                    intArrayOf(Color.parseColor("#553B82FF"), Color.parseColor("#087C5CFF"))
                ).apply { cornerRadius = dp(9).toFloat() } else null
            }
            holder.removeAllViews()
            val list = buildList(name, tabs[name]!!)
            holder.addView(list)
            holder.scrollTo(0, 0)
            list.alpha = 0f
            list.translationY = dp(8).toFloat()
            list.animate().alpha(1f).translationY(0f).setDuration(220).start()
        }
        reselect = { select(current) }

        tabs.keys.forEach { name ->
            val t = TextView(ctx).apply {
                text = "  $name"
                tag = name
                textSize = 13f
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), 0, dp(8), 0)
                setOnClickListener { select(name) }
            }
            tabViews.add(t)
            side.addView(t, LinearLayout.LayoutParams(-1, dp(38)).apply { bottomMargin = dp(3) })
        }
        body.addView(side, LinearLayout.LayoutParams(dp(104), dp(262)))
        body.addView(holder, LinearLayout.LayoutParams(0, dp(262), 1f).apply { leftMargin = dp(8) })
        gui.addView(body)

        // footer
        val footer = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        footer.addView(label("●  Injected", 10f, C_GREEN, true), LinearLayout.LayoutParams(0, -2, 1f))
        footer.addView(label("drag header to move", 10f, C_MUTED))
        gui.addView(footer, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        select(current)

        gui.alpha = 0f
        gui.scaleX = 0.92f
        gui.scaleY = 0.92f
        gui.pivotX = 0f
        gui.pivotY = 0f
        wm.addView(gui, guiParams)
        gui.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(280)
            .setInterpolator(OvershootInterpolator(1.1f)).start()
    }

    private fun buildList(tab: String, items: List<Item>): View {
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        items.forEach { item ->
            when (item) {
                is Item.Header -> col.addView(
                    label(item.text, 10f, C_MUTED, true).apply { letterSpacing = 0.15f },
                    LinearLayout.LayoutParams(-2, -2).apply {
                        topMargin = dp(4); bottomMargin = dp(5); leftMargin = dp(4)
                    })

                is Item.Toggle -> {
                    val key = "t_${tab}_${item.label}"
                    val tg = ToggleView(ctx, prefs.getBoolean(key, item.def)) { v ->
                        prefs.edit().putBoolean(key, v).apply()
                    }
                    val row = LinearLayout(ctx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        background = rounded(C_CARD, dp(10), C_STROKE)
                        setPadding(dp(12), 0, dp(12), 0)
                    }
                    row.addView(label(item.label, 13f, C_TEXT), LinearLayout.LayoutParams(0, -2, 1f))
                    row.addView(tg, LinearLayout.LayoutParams(dp(40), dp(22)))
                    row.setOnClickListener { tg.toggle() }
                    col.addView(row, LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(5) })
                }

                is Item.Slider -> {
                    val key = "s_${tab}_${item.label}"
                    val start = prefs.getInt(key, item.def)
                    val card = LinearLayout(ctx).apply {
                        orientation = LinearLayout.VERTICAL
                        background = rounded(C_CARD, dp(10), C_STROKE)
                        setPadding(dp(12), dp(8), dp(12), dp(6))
                    }
                    val top = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
                    val valueTv = label("$start${item.suffix}", 12f, C_ACCENT, true)
                    top.addView(label(item.label, 13f, C_TEXT), LinearLayout.LayoutParams(0, -2, 1f))
                    top.addView(valueTv)
                    val sl = SliderView(ctx, item.min, item.max, start) { v ->
                        valueTv.text = "$v${item.suffix}"
                        prefs.edit().putInt(key, v).apply()
                    }
                    card.addView(top)
                    card.addView(sl, LinearLayout.LayoutParams(-1, dp(24)))
                    col.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
                }

                is Item.Action -> {
                    val b = chip(item.label, true) {
                        prefs.edit().clear().apply()
                        reselect?.invoke()
                    }
                    col.addView(b, LinearLayout.LayoutParams(-1, dp(38)).apply { topMargin = dp(6) })
                }

                Item.Money -> col.addView(
                    buildMoney(),
                    LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
            }
        }
        return col
    }

    // ---------- money card ----------
    private fun buildMoney(): View {
        var money = prefs.getLong("money", 50_000L).coerceIn(0L, MONEY_MAX)
        var shown = money
        var curIdx = prefs.getInt("cur", 0).coerceIn(0, currencies.size - 1)
        var editing = false
        var anim: ValueAnimator? = null
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager

        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#16233F"), Color.parseColor("#120E26"))
            ).apply { cornerRadius = dp(12).toFloat(); setStroke(dp(1), C_STROKE) }
            setPadding(dp(12), dp(10), dp(12), dp(12))
        }

        val top = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val amount = label("", 26f, Color.WHITE, true)
        val edit = EditText(ctx).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            imeOptions = EditorInfo.IME_ACTION_DONE
            setSingleLine(true)
            setTextColor(Color.WHITE)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(C_PANEL, dp(8), C_ACCENT)
            setPadding(dp(10), dp(4), dp(10), dp(4))
            visibility = View.GONE
        }

        fun render() {
            amount.text = "${currencies[curIdx]} ${fmt(shown)}"
        }

        fun setMoney(v: Long, animate: Boolean) {
            val target = v.coerceIn(0L, MONEY_MAX)
            val from = shown
            money = target
            prefs.edit().putLong("money", target).apply()
            anim?.cancel()
            if (!animate) {
                shown = target
                render()
                return
            }
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 450
                interpolator = DecelerateInterpolator()
                addUpdateListener {
                    val f = it.animatedValue as Float
                    shown = if (f >= 1f) target else from + ((target - from) * f).toLong()
                    render()
                }
                start()
            }
            amount.animate().scaleX(1.06f).scaleY(1.06f).setDuration(120).withEndAction {
                amount.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
            }.start()
        }

        val editBtn = chip("EDIT", false) {}
        val curBtn = chip(currencies[curIdx], false) {
            curIdx = (curIdx + 1) % currencies.size
            prefs.edit().putInt("cur", curIdx).apply()
            (it as TextView).text = currencies[curIdx]
            render()
        }

        fun endEdit(apply: Boolean) {
            if (!editing) return
            editing = false
            if (apply) {
                val v = edit.text.toString().filter { c -> c.isDigit() }.take(12).toLongOrNull()
                if (v != null) setMoney(v, true)
            }
            imm.hideSoftInputFromWindow(edit.windowToken, 0)
            edit.visibility = View.GONE
            amount.visibility = View.VISIBLE
            editBtn.text = "EDIT"
            setFocusable(false)
        }

        fun startEdit() {
            editing = true
            amount.visibility = View.GONE
            edit.visibility = View.VISIBLE
            edit.setText(money.toString())
            edit.setSelection(edit.text.length)
            editBtn.text = "OK"
            setFocusable(true)
            edit.post {
                edit.requestFocus()
                imm.showSoftInput(edit, InputMethodManager.SHOW_IMPLICIT)
            }
        }

        editBtn.setOnClickListener { if (editing) endEdit(true) else startEdit() }
        edit.setOnEditorActionListener { _, _, _ -> endEdit(true); true }

        top.addView(label("BALANCE", 10f, C_MUTED, true).apply { letterSpacing = 0.15f },
            LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(editBtn, LinearLayout.LayoutParams(dp(46), dp(24)).apply { rightMargin = dp(6) })
        top.addView(curBtn, LinearLayout.LayoutParams(dp(30), dp(24)))
        card.addView(top)

        card.addView(amount, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4); bottomMargin = dp(8) })
        card.addView(edit, LinearLayout.LayoutParams(-1, dp(40)).apply { topMargin = dp(4); bottomMargin = dp(8) })

        fun chipRow(vararg specs: Triple<String, Boolean, () -> Unit>) {
            val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            specs.forEachIndexed { i, s ->
                r.addView(chip(s.first, s.second, s.third),
                    LinearLayout.LayoutParams(0, dp(30), 1f).apply { if (i > 0) leftMargin = dp(5) })
            }
            card.addView(r, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
        }
        chipRow(
            Triple("-10K", false) { setMoney(money - 10_000, true) },
            Triple("-1K", false) { setMoney(money - 1_000, true) },
            Triple("+1K", false) { setMoney(money + 1_000, true) },
            Triple("+10K", false) { setMoney(money + 10_000, true) }
        )
        chipRow(
            Triple("+100K", true) { setMoney(money + 100_000, true) },
            Triple("+1M", true) { setMoney(money + 1_000_000, true) },
            Triple("×2", true) { setMoney(money * 2, true) },
            Triple("RESET", false) { setMoney(0, true) }
        )

        render()
        return card
    }

    // ---------- open button / hide / show ----------
    private fun buildOpenButton() {
        openParams = lp(guiParams.x, guiParams.y, WindowManager.LayoutParams.WRAP_CONTENT)
        openBtn = TextView(ctx).apply {
            text = "◆  OPEN GUI"
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.08f
            setPadding(dp(18), dp(11), dp(18), dp(11))
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(C_ACCENT, C_ACCENT2)
            ).apply { cornerRadius = dp(22).toFloat() }
        }
        attachDrag(openBtn, openParams, openBtn, { showGui() }) {}
    }

    private fun hideGui() {
        gui.pivotX = 0f
        gui.pivotY = 0f
        gui.animate().alpha(0f).scaleX(0.5f).scaleY(0.5f).setDuration(240)
            .setInterpolator(DecelerateInterpolator()).withEndAction {
                gui.visibility = View.GONE
                openParams.x = guiParams.x
                openParams.y = guiParams.y
                openBtn.alpha = 0f
                openBtn.scaleX = 0.8f
                openBtn.scaleY = 0.8f
                wm.addView(openBtn, openParams)
                openShown = true
                openBtn.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).start()
            }.start()
    }

    private fun showGui() {
        guiParams.x = openParams.x
        guiParams.y = openParams.y
        prefs.edit().putInt("x", guiParams.x).putInt("y", guiParams.y).apply()
        wm.updateViewLayout(gui, guiParams)
        if (openShown) {
            wm.removeView(openBtn)
            openShown = false
        }
        gui.visibility = View.VISIBLE
        gui.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260)
            .setInterpolator(OvershootInterpolator(1.1f)).start()
    }

    private fun attachDrag(
        handle: View, p: WindowManager.LayoutParams, target: View,
        onClick: (() -> Unit)?, onEnd: () -> Unit
    ) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt()
                    val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > dp(5) || abs(dy) > dp(5)) moved = true
                    p.x = ox + dx
                    p.y = oy + dy
                    wm.updateViewLayout(target, p)
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onClick?.invoke() else onEnd()
                }
            }
            true
        }
    }

    override fun onDestroy() {
        runCatching { wm.removeView(gui) }
        if (openShown) runCatching { wm.removeView(openBtn) }
        super.onDestroy()
    }
}
