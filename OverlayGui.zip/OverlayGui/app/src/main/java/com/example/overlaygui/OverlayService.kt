package com.example.overlaygui

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

private val BG = Color.parseColor("#F2050810")
private val PANEL = Color.parseColor("#0B1019")
private val STROKE = Color.parseColor("#1B2A44")
private val ACCENT = Color.parseColor("#2D7DFF")
private val TEXT = Color.parseColor("#DCE4F2")
private val MUTED = Color.parseColor("#6B7A96")

class ToggleView(ctx: Context) : View(ctx) {
    var on = false
        private set
    private var progress = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ev = ArgbEvaluator()

    fun toggle() {
        on = !on
        ValueAnimator.ofFloat(progress, if (on) 1f else 0f).apply {
            duration = 180
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.color = ev.evaluate(progress, Color.parseColor("#232C3B"), ACCENT) as Int
        c.drawRoundRect(0f, 0f, w, h, h / 2, p)
        p.color = Color.WHITE
        val r = h / 2 - 3 * resources.displayMetrics.density
        val cx = h / 2 + progress * (w - h)
        c.drawCircle(cx, h / 2, r, p)
    }
}

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var gui: LinearLayout
    private lateinit var guiParams: WindowManager.LayoutParams
    private lateinit var openBtn: TextView
    private lateinit var openParams: WindowManager.LayoutParams
    private var openShown = false
    private val d get() = resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()

    private val tabs = linkedMapOf(
        "Ragebot" to listOf("Enabled", "Auto fire", "Silent aim", "Auto scope", "Auto stop", "Resolver"),
        "Legitbot" to listOf("Enabled", "Smooth aim", "Recoil control", "Trigger", "Backtrack"),
        "Visuals" to listOf("Box", "Name", "Health bar", "Skeleton", "Glow", "Chams", "Radar"),
        "Misc" to listOf("Bunny hop", "Auto strafe", "Watermark", "Spectator list", "Hit sound"),
        "Config" to listOf("Auto save", "Show keybinds", "Dark theme")
    )

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildGui()
        buildOpenButton()
    }

    private fun rounded(color: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = r.toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun lp(x: Int, y: Int, w: Int) = WindowManager.LayoutParams(
        w, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun headerBtn(label: String, click: () -> Unit) = TextView(this).apply {
        text = label; setTextColor(TEXT); textSize = 16f; gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        background = rounded(Color.parseColor("#141C2B"), dp(8))
        setOnClickListener { click() }
    }

    private fun buildGui() {
        guiParams = lp(dp(40), dp(80), dp(400))
        gui = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(BG, dp(14), STROKE)
            setPadding(dp(10), dp(8), dp(10), dp(10))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "NIGHTFALL"; setTextColor(ACCENT); textSize = 16f
            typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.15f
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(headerBtn("–") { hideGui() }, LinearLayout.LayoutParams(dp(30), dp(30)).apply { rightMargin = dp(6) })
        header.addView(headerBtn("✕") { stopSelf() }, LinearLayout.LayoutParams(dp(30), dp(30)))
        gui.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        attachDrag(header, guiParams, gui, null)

        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val side = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(PANEL, dp(10))
            setPadding(dp(4), dp(6), dp(4), dp(6))
        }
        val listHolder = ScrollView(this).apply {
            background = rounded(PANEL, dp(10)); isVerticalScrollBarEnabled = false
        }
        val tabViews = mutableListOf<TextView>()
        fun select(name: String) {
            tabViews.forEach {
                val sel = it.text == name
                it.setTextColor(if (sel) Color.WHITE else MUTED)
                it.background = if (sel) rounded(Color.parseColor("#1A2B4D"), dp(8)) else null
            }
            listHolder.removeAllViews()
            listHolder.addView(buildList(tabs[name]!!))
            listHolder.scrollTo(0, 0)
        }
        tabs.keys.forEach { name ->
            val t = TextView(this).apply {
                text = name; textSize = 13f; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), 0, dp(10), 0)
                setOnClickListener { select(name) }
            }
            tabViews.add(t)
            side.addView(t, LinearLayout.LayoutParams(-1, dp(36)).apply { bottomMargin = dp(2) })
        }
        body.addView(side, LinearLayout.LayoutParams(dp(100), dp(230)))
        body.addView(listHolder, LinearLayout.LayoutParams(0, dp(230), 1f).apply { leftMargin = dp(8) })
        gui.addView(body)
        select(tabs.keys.first())

        wm.addView(gui, guiParams)
    }

    private fun buildList(items: List<String>): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        items.forEach { label ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            }
            val tv = TextView(this).apply { text = label; setTextColor(TEXT); textSize = 13f }
            val tg = ToggleView(this)
            row.addView(tv, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(tg, LinearLayout.LayoutParams(dp(38), dp(20)))
            row.setOnClickListener { tg.toggle() }
            col.addView(row, LinearLayout.LayoutParams(-1, dp(38)))
        }
        return col
    }

    private fun buildOpenButton() {
        openParams = lp(dp(40), dp(80), WindowManager.LayoutParams.WRAP_CONTENT)
        openBtn = TextView(this).apply {
            text = "OPEN GUI"; setTextColor(Color.WHITE); textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = rounded(ACCENT, dp(20))
        }
        attachDrag(openBtn, openParams, openBtn) { showGui() }
    }

    private fun hideGui() {
        gui.pivotX = 0f; gui.pivotY = 0f
        gui.animate().alpha(0f).scaleX(0.6f).scaleY(0.6f).setDuration(220).withEndAction {
            gui.visibility = View.GONE
            openParams.x = guiParams.x; openParams.y = guiParams.y
            openBtn.alpha = 0f
            wm.addView(openBtn, openParams); openShown = true
            openBtn.animate().alpha(1f).setDuration(180).start()
        }.start()
    }

    private fun showGui() {
        guiParams.x = openParams.x; guiParams.y = openParams.y
        wm.updateViewLayout(gui, guiParams)
        if (openShown) { wm.removeView(openBtn); openShown = false }
        gui.visibility = View.VISIBLE
        gui.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).start()
    }

    private fun attachDrag(handle: View, p: WindowManager.LayoutParams, target: View, onClick: (() -> Unit)?) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) moved = true
                    p.x = ox + dx; p.y = oy + dy
                    wm.updateViewLayout(target, p)
                }
                MotionEvent.ACTION_UP -> if (!moved) onClick?.invoke()
            }
            true
        }
    }

    override fun onDestroy() {
        runCatching { wm.removeView(gui) }
        if (openShown) runCatching { wm.removeView(openBtn) }
        super.onDestroy()
    }
}
